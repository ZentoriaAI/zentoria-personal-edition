import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Conversation, ChatMessage } from '@/types';

// ============================
// Chat Store
// ============================

interface ChatState {
  // Current conversation
  currentConversationId: string | null;
  conversations: Conversation[];
  messages: Map<string, ChatMessage[]>; // conversationId -> messages

  // Input state
  inputValue: string;
  isStreaming: boolean;
  streamingContent: string;

  // Attachments
  pendingAttachments: File[];

  // Actions
  setCurrentConversation: (id: string | null) => void;
  setConversations: (conversations: Conversation[]) => void;
  addConversation: (conversation: Conversation) => void;
  updateConversation: (id: string, updates: Partial<Conversation>) => void;
  removeConversation: (id: string) => void;

  setMessages: (conversationId: string, messages: ChatMessage[]) => void;
  addMessage: (conversationId: string, message: ChatMessage) => void;
  updateMessage: (conversationId: string, messageId: string, updates: Partial<ChatMessage>) => void;

  setInputValue: (value: string) => void;
  setIsStreaming: (streaming: boolean) => void;
  appendStreamingContent: (content: string) => void;
  clearStreamingContent: () => void;

  addAttachment: (file: File) => void;
  removeAttachment: (index: number) => void;
  clearAttachments: () => void;

  reset: () => void;
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      currentConversationId: null,
      conversations: [],
      messages: new Map(),
      inputValue: '',
      isStreaming: false,
      streamingContent: '',
      pendingAttachments: [],

      setCurrentConversation: (id) => set({ currentConversationId: id }),

      setConversations: (conversations) => set({ conversations }),

      addConversation: (conversation) =>
        set((state) => ({
          conversations: [conversation, ...state.conversations],
        })),

      updateConversation: (id, updates) =>
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === id ? { ...c, ...updates } : c
          ),
        })),

      removeConversation: (id) =>
        set((state) => {
          const newMessages = new Map(state.messages);
          newMessages.delete(id);
          return {
            conversations: state.conversations.filter((c) => c.id !== id),
            messages: newMessages,
            currentConversationId:
              state.currentConversationId === id ? null : state.currentConversationId,
          };
        }),

      setMessages: (conversationId, messages) =>
        set((state) => {
          const newMessages = new Map(state.messages);
          newMessages.set(conversationId, messages);
          return { messages: newMessages };
        }),

      addMessage: (conversationId, message) =>
        set((state) => {
          const newMessages = new Map(state.messages);
          const existing = newMessages.get(conversationId) || [];
          newMessages.set(conversationId, [...existing, message]);
          return { messages: newMessages };
        }),

      updateMessage: (conversationId, messageId, updates) =>
        set((state) => {
          const newMessages = new Map(state.messages);
          const existing = newMessages.get(conversationId) || [];
          newMessages.set(
            conversationId,
            existing.map((m) => (m.id === messageId ? { ...m, ...updates } : m))
          );
          return { messages: newMessages };
        }),

      setInputValue: (value) => set({ inputValue: value }),

      setIsStreaming: (streaming) => set({ isStreaming: streaming }),

      appendStreamingContent: (content) =>
        set((state) => ({
          streamingContent: state.streamingContent + content,
        })),

      clearStreamingContent: () => set({ streamingContent: '' }),

      addAttachment: (file) =>
        set((state) => ({
          pendingAttachments: [...state.pendingAttachments, file],
        })),

      removeAttachment: (index) =>
        set((state) => ({
          pendingAttachments: state.pendingAttachments.filter((_, i) => i !== index),
        })),

      clearAttachments: () => set({ pendingAttachments: [] }),

      reset: () =>
        set({
          currentConversationId: null,
          conversations: [],
          messages: new Map(),
          inputValue: '',
          isStreaming: false,
          streamingContent: '',
          pendingAttachments: [],
        }),
    }),
    {
      name: 'zentoria-chat',
      partialize: (state) => ({
        conversations: state.conversations.slice(0, 20), // Only persist recent conversations
      }),
    }
  )
);

// Selectors
export const selectCurrentMessages = () => {
  const { currentConversationId, messages } = useChatStore.getState();
  if (!currentConversationId) return [];
  return messages.get(currentConversationId) || [];
};

export const selectCurrentConversation = () => {
  const { currentConversationId, conversations } = useChatStore.getState();
  if (!currentConversationId) return null;
  return conversations.find((c) => c.id === currentConversationId) || null;
};
