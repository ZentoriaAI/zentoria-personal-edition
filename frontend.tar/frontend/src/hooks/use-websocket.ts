'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'ws://10.10.40.101:4000';

export type ConnectionStatus = 'connecting' | 'connected' | 'disconnected' | 'error';

interface UseWebSocketOptions {
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Error) => void;
  autoConnect?: boolean;
}

interface UseWebSocketReturn {
  socket: Socket | null;
  status: ConnectionStatus;
  connect: () => void;
  disconnect: () => void;
  emit: (event: string, data?: unknown) => void;
  on: (event: string, callback: (...args: unknown[]) => void) => void;
  off: (event: string, callback?: (...args: unknown[]) => void) => void;
}

export function useWebSocket(options: UseWebSocketOptions = {}): UseWebSocketReturn {
  const { onConnect, onDisconnect, onError, autoConnect = true } = options;
  const socketRef = useRef<Socket | null>(null);
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');

  const connect = useCallback(() => {
    if (socketRef.current?.connected) return;

    setStatus('connecting');

    const socket = io(WS_URL, {
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socket.on('connect', () => {
      setStatus('connected');
      onConnect?.();
    });

    socket.on('disconnect', () => {
      setStatus('disconnected');
      onDisconnect?.();
    });

    socket.on('connect_error', (error) => {
      setStatus('error');
      onError?.(error);
    });

    socketRef.current = socket;
  }, [onConnect, onDisconnect, onError]);

  const disconnect = useCallback(() => {
    socketRef.current?.disconnect();
    socketRef.current = null;
    setStatus('disconnected');
  }, []);

  const emit = useCallback((event: string, data?: unknown) => {
    socketRef.current?.emit(event, data);
  }, []);

  const on = useCallback((event: string, callback: (...args: unknown[]) => void) => {
    socketRef.current?.on(event, callback);
  }, []);

  const off = useCallback((event: string, callback?: (...args: unknown[]) => void) => {
    if (callback) {
      socketRef.current?.off(event, callback);
    } else {
      socketRef.current?.off(event);
    }
  }, []);

  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  return {
    socket: socketRef.current,
    status,
    connect,
    disconnect,
    emit,
    on,
    off,
  };
}

// Hook for real-time system health updates
export function useSystemHealth() {
  const [health, setHealth] = useState<unknown>(null);
  const { on, off, status } = useWebSocket();

  useEffect(() => {
    const handleHealthUpdate = (data: unknown) => {
      setHealth(data);
    };

    on('health:update', handleHealthUpdate);

    return () => {
      off('health:update', handleHealthUpdate);
    };
  }, [on, off]);

  return { health, connectionStatus: status };
}

// Hook for real-time workflow execution updates
export function useWorkflowUpdates(workflowId?: string) {
  const [executions, setExecutions] = useState<unknown[]>([]);
  const { on, off, emit, status } = useWebSocket();

  useEffect(() => {
    if (workflowId) {
      emit('workflow:subscribe', { workflowId });
    }

    const handleExecutionUpdate = (data: unknown) => {
      setExecutions((prev) => [data, ...prev].slice(0, 50));
    };

    on('workflow:execution', handleExecutionUpdate);

    return () => {
      if (workflowId) {
        emit('workflow:unsubscribe', { workflowId });
      }
      off('workflow:execution', handleExecutionUpdate);
    };
  }, [workflowId, on, off, emit]);

  return { executions, connectionStatus: status };
}

// Hook for real-time log streaming
export function useLogStream(filter?: { level?: string; source?: string }) {
  const [logs, setLogs] = useState<unknown[]>([]);
  const { on, off, emit, status } = useWebSocket();

  useEffect(() => {
    emit('logs:subscribe', filter);

    const handleLog = (data: unknown) => {
      setLogs((prev) => [data, ...prev].slice(0, 100));
    };

    on('logs:entry', handleLog);

    return () => {
      emit('logs:unsubscribe');
      off('logs:entry', handleLog);
    };
  }, [filter, on, off, emit]);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  return { logs, clearLogs, connectionStatus: status };
}
