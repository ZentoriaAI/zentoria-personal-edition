"""Zentoria AI Orchestrator - Route AI commands to appropriate agents."""

__version__ = "1.0.0"
