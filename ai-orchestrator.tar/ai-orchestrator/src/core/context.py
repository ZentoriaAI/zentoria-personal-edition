"""Context manager for conversation memory."""

import json
from datetime import datetime
from typing import Any

import redis.asyncio as redis
import structlog
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

from src.config import Settings, get_settings
from src.core.models import Conversation, Message, MessageRole

logger = structlog.get_logger(__name__)


class ContextManager:
    """Manage conversation context with Redis (short-term) and Qdrant (long-term)."""

    def __init__(self, settings: Settings | None = None) -> None:
        """Initialize the context manager."""
        self.settings = settings or get_settings()
        self._redis: redis.Redis | None = None
        self._qdrant: AsyncQdrantClient | None = None

    async def _get_redis(self) -> redis.Redis:
        """Get or create Redis connection."""
        if self._redis is None:
            password = (
                self.settings.redis_password.get_secret_value()
                if self.settings.redis_password
                else None
            )
            self._redis = redis.Redis.from_url(
                self.settings.redis_url,
                password=password,
                db=self.settings.redis_db,
                decode_responses=True,
            )
        return self._redis

    async def _get_qdrant(self) -> AsyncQdrantClient:
        """Get or create Qdrant client."""
        if self._qdrant is None:
            api_key = (
                self.settings.qdrant_api_key.get_secret_value()
                if self.settings.qdrant_api_key
                else None
            )
            self._qdrant = AsyncQdrantClient(
                url=self.settings.qdrant_url,
                api_key=api_key,
            )
            # Ensure collection exists
            await self._ensure_collection()
        return self._qdrant

    async def _ensure_collection(self) -> None:
        """Ensure the Qdrant collection exists."""
        if self._qdrant is None:
            return

        collections = await self._qdrant.get_collections()
        collection_names = [c.name for c in collections.collections]

        if self.settings.qdrant_collection not in collection_names:
            await self._qdrant.create_collection(
                collection_name=self.settings.qdrant_collection,
                vectors_config=VectorParams(
                    size=self.settings.qdrant_embedding_size,
                    distance=Distance.COSINE,
                ),
            )
            logger.info(
                "Created Qdrant collection", collection=self.settings.qdrant_collection
            )

    async def close(self) -> None:
        """Close connections."""
        if self._redis:
            await self._redis.close()
        if self._qdrant:
            await self._qdrant.close()

    def _conversation_key(self, session_id: str) -> str:
        """Get Redis key for a conversation."""
        return f"zentoria:conversation:{session_id}"

    def _user_prefs_key(self, user_id: str) -> str:
        """Get Redis key for user preferences."""
        return f"zentoria:user:{user_id}:preferences"

    async def get_conversation(self, session_id: str) -> Conversation:
        """Get conversation by session ID.

        Args:
            session_id: Session identifier

        Returns:
            Conversation object
        """
        r = await self._get_redis()
        key = self._conversation_key(session_id)

        data = await r.get(key)
        if data:
            conv_dict = json.loads(data)
            return Conversation(**conv_dict)

        # Create new conversation
        return Conversation(session_id=session_id)

    async def save_conversation(self, conversation: Conversation) -> None:
        """Save conversation to Redis.

        Args:
            conversation: Conversation to save
        """
        r = await self._get_redis()
        key = self._conversation_key(conversation.session_id)

        # Trim to max history
        if len(conversation.messages) > self.settings.redis_max_history:
            conversation.messages = conversation.messages[
                -self.settings.redis_max_history :
            ]

        conversation.updated_at = datetime.utcnow()

        await r.setex(
            key,
            self.settings.redis_conversation_ttl,
            conversation.model_dump_json(),
        )

        logger.debug(
            "Saved conversation",
            session_id=conversation.session_id,
            message_count=len(conversation.messages),
        )

    async def add_message(
        self,
        session_id: str,
        role: MessageRole,
        content: str,
        **kwargs: Any,
    ) -> Message:
        """Add a message to conversation.

        Args:
            session_id: Session identifier
            role: Message role
            content: Message content
            **kwargs: Additional message fields

        Returns:
            Created message
        """
        conversation = await self.get_conversation(session_id)
        message = Message(role=role, content=content, **kwargs)
        conversation.messages.append(message)
        await self.save_conversation(conversation)

        return message

    async def clear_conversation(self, session_id: str) -> bool:
        """Clear conversation history.

        Args:
            session_id: Session identifier

        Returns:
            True if cleared, False if not found
        """
        r = await self._get_redis()
        key = self._conversation_key(session_id)
        result = await r.delete(key)
        return result > 0

    async def get_user_preferences(self, user_id: str) -> dict[str, Any]:
        """Get user preferences.

        Args:
            user_id: User identifier

        Returns:
            User preferences dict
        """
        r = await self._get_redis()
        key = self._user_prefs_key(user_id)

        data = await r.get(key)
        if data:
            return json.loads(data)
        return {}

    async def set_user_preferences(
        self,
        user_id: str,
        preferences: dict[str, Any],
    ) -> None:
        """Set user preferences.

        Args:
            user_id: User identifier
            preferences: Preferences to set
        """
        r = await self._get_redis()
        key = self._user_prefs_key(user_id)

        # Merge with existing
        existing = await self.get_user_preferences(user_id)
        existing.update(preferences)

        await r.set(key, json.dumps(existing))

    async def store_memory(
        self,
        session_id: str,
        content: str,
        embedding: list[float],
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store long-term memory in Qdrant.

        Args:
            session_id: Session identifier
            content: Memory content
            embedding: Embedding vector
            metadata: Additional metadata

        Returns:
            Point ID
        """
        qdrant = await self._get_qdrant()

        import uuid

        point_id = str(uuid.uuid4())

        payload = {
            "session_id": session_id,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
            **(metadata or {}),
        }

        await qdrant.upsert(
            collection_name=self.settings.qdrant_collection,
            points=[
                PointStruct(
                    id=point_id,
                    vector=embedding,
                    payload=payload,
                )
            ],
        )

        logger.debug("Stored memory", point_id=point_id, session_id=session_id)

        return point_id

    async def search_memories(
        self,
        embedding: list[float],
        session_id: str | None = None,
        limit: int = 5,
        score_threshold: float = 0.7,
    ) -> list[dict[str, Any]]:
        """Search long-term memories.

        Args:
            embedding: Query embedding
            session_id: Optional session filter
            limit: Max results
            score_threshold: Minimum score

        Returns:
            List of matching memories
        """
        qdrant = await self._get_qdrant()

        filter_conditions = None
        if session_id:
            from qdrant_client.models import FieldCondition, Filter, MatchValue

            filter_conditions = Filter(
                must=[
                    FieldCondition(
                        key="session_id",
                        match=MatchValue(value=session_id),
                    )
                ]
            )

        results = await qdrant.search(
            collection_name=self.settings.qdrant_collection,
            query_vector=embedding,
            query_filter=filter_conditions,
            limit=limit,
            score_threshold=score_threshold,
        )

        memories = []
        for hit in results:
            payload = hit.payload or {}
            memories.append(
                {
                    "id": hit.id,
                    "content": payload.get("content", ""),
                    "score": hit.score,
                    "metadata": {k: v for k, v in payload.items() if k != "content"},
                }
            )

        return memories

    async def check_redis_health(self) -> bool:
        """Check Redis health."""
        try:
            r = await self._get_redis()
            await r.ping()
            return True
        except Exception as e:
            logger.warning("Redis health check failed", error=str(e))
            return False

    async def check_qdrant_health(self) -> bool:
        """Check Qdrant health."""
        try:
            qdrant = await self._get_qdrant()
            await qdrant.get_collections()
            return True
        except Exception as e:
            logger.warning("Qdrant health check failed", error=str(e))
            return False


# Global instance
_context_manager: ContextManager | None = None


async def get_context_manager() -> ContextManager:
    """Get the global context manager instance."""
    global _context_manager
    if _context_manager is None:
        _context_manager = ContextManager()
    return _context_manager
