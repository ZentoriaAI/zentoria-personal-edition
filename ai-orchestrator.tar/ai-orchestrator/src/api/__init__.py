"""API routes for the AI Orchestrator."""

from src.api.routes import router

__all__ = ["router"]
