'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FileText,
  Search,
  Filter,
  Trash2,
  RefreshCw,
  AlertCircle,
  AlertTriangle,
  Info,
  Bug,
  ChevronDown,
  ChevronUp,
  Calendar,
  Download,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input, SearchInput } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { apiClient } from '@/lib/api-client';
import { toast } from '@/stores/app-store';
import { cn, formatRelativeTime } from '@/lib/utils';
import type { LogEntry, LogLevel, LogFilter } from '@/types';

const logLevelConfig: Record<LogLevel, {
  icon: React.ElementType;
  color: string;
  bgColor: string;
  label: string;
}> = {
  debug: {
    icon: Bug,
    color: 'text-gray-500',
    bgColor: 'bg-gray-500/10',
    label: 'Debug',
  },
  info: {
    icon: Info,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    label: 'Info',
  },
  warn: {
    icon: AlertTriangle,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/10',
    label: 'Warning',
  },
  error: {
    icon: AlertCircle,
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    label: 'Error',
  },
};

export default function LogsPage() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<LogFilter>({
    page: 1,
    pageSize: 50,
  });
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [selectedLevels, setSelectedLevels] = useState<Set<LogLevel>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch logs
  const { data: logsData, isLoading, refetch } = useQuery({
    queryKey: ['logs', filter],
    queryFn: () => apiClient.getLogs({
      ...filter,
      level: selectedLevels.size > 0 ? Array.from(selectedLevels) : undefined,
      search: searchQuery || undefined,
    }),
    refetchInterval: 10000,
  });

  // Clear logs mutation
  const clearLogs = useMutation({
    mutationFn: () => apiClient.clearLogs(),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast({ title: `Cleared ${data.deleted} logs`, variant: 'success' });
      setShowClearDialog(false);
    },
    onError: (error) => {
      toast({ title: 'Failed to clear logs', description: error.message, variant: 'error' });
    },
  });

  // Toggle level filter
  const toggleLevel = (level: LogLevel) => {
    setSelectedLevels((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(level)) {
        newSet.delete(level);
      } else {
        newSet.add(level);
      }
      return newSet;
    });
  };

  // Handle search
  const handleSearch = () => {
    setFilter((prev) => ({ ...prev, page: 1 }));
  };

  const logs = logsData?.items || [];
  const totalPages = logsData?.totalPages || 1;

  // Count by level
  const levelCounts = logs.reduce((acc, log) => {
    acc[log.level] = (acc[log.level] || 0) + 1;
    return acc;
  }, {} as Record<LogLevel, number>);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-lg font-semibold">System Logs</h2>
          <p className="text-sm text-muted-foreground">
            View and manage system log entries
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="destructive" onClick={() => setShowClearDialog(true)}>
            <Trash2 className="h-4 w-4 mr-2" />
            Clear Logs
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="flex-1 min-w-[200px]">
              <SearchInput
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>

            {/* Level filters */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Level:</span>
              {(Object.keys(logLevelConfig) as LogLevel[]).map((level) => {
                const config = logLevelConfig[level];
                const isActive = selectedLevels.has(level);
                return (
                  <button
                    key={level}
                    onClick={() => toggleLevel(level)}
                    className={cn(
                      'flex items-center gap-1.5 px-2 py-1 rounded-lg text-sm transition-all',
                      isActive
                        ? `${config.bgColor} ${config.color}`
                        : 'bg-light-surface dark:bg-dark-elevated hover:opacity-80'
                    )}
                  >
                    <config.icon className="h-3.5 w-3.5" />
                    <span>{config.label}</span>
                    {levelCounts[level] && (
                      <Badge variant="secondary" className="ml-1 text-xs">
                        {levelCounts[level]}
                      </Badge>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs list */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-3">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="skeleton h-16 rounded-lg" />
              ))}
            </div>
          ) : logs.length > 0 ? (
            <div className="divide-y">
              {logs.map((log) => {
                const config = logLevelConfig[log.level];
                const isExpanded = expandedLog === log.id;

                return (
                  <div
                    key={log.id}
                    className="p-4 hover:bg-light-hover dark:hover:bg-dark-hover transition-colors"
                  >
                    <div
                      className="flex items-start gap-3 cursor-pointer"
                      onClick={() => setExpandedLog(isExpanded ? null : log.id)}
                    >
                      {/* Level icon */}
                      <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center shrink-0', config.bgColor)}>
                        <config.icon className={cn('h-4 w-4', config.color)} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={
                            log.level === 'error' ? 'error' :
                            log.level === 'warn' ? 'warning' :
                            log.level === 'info' ? 'online' : 'secondary'
                          }>
                            {log.level}
                          </Badge>
                          <span className="text-sm font-medium text-muted-foreground">
                            {log.source}
                          </span>
                        </div>
                        <p className={cn('text-sm', isExpanded ? '' : 'line-clamp-2')}>
                          {log.message}
                        </p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {formatRelativeTime(log.timestamp)}
                        </div>
                      </div>

                      {/* Expand icon */}
                      {log.metadata && Object.keys(log.metadata).length > 0 && (
                        <Button variant="ghost" size="icon-sm">
                          {isExpanded ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </Button>
                      )}
                    </div>

                    {/* Expanded metadata */}
                    {isExpanded && log.metadata && Object.keys(log.metadata).length > 0 && (
                      <div className="mt-3 ml-11 p-3 bg-dark-bg rounded-lg">
                        <pre className="text-xs text-gray-300 overflow-x-auto">
                          {JSON.stringify(log.metadata, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-16 text-center">
              <FileText className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No logs found</h3>
              <p className="text-muted-foreground">
                {searchQuery || selectedLevels.size > 0
                  ? 'Try adjusting your filters'
                  : 'System logs will appear here'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {filter.page} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={filter.page === 1}
              onClick={() => setFilter((prev) => ({ ...prev, page: (prev.page || 1) - 1 }))}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={filter.page === totalPages}
              onClick={() => setFilter((prev) => ({ ...prev, page: (prev.page || 1) + 1 }))}
            >
              Next
            </Button>
          </div>
        </div>
      )}

      {/* Clear dialog */}
      <Dialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear System Logs</DialogTitle>
            <DialogDescription>
              This will permanently delete all system logs. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => clearLogs.mutate()}
              disabled={clearLogs.isPending}
            >
              {clearLogs.isPending ? 'Clearing...' : 'Clear All Logs'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
