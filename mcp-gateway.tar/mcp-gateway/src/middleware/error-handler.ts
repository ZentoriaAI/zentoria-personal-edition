/**
 * Global Error Handler
 *
 * Provides consistent error responses and logging
 */

import { FastifyError, FastifyRequest, FastifyReply } from 'fastify';
import { ZodError } from 'zod';
import { logger } from '../infrastructure/logger.js';

/**
 * Application-specific error class
 */
export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode: number = 400,
    public readonly details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'AppError';
    Error.captureStackTrace(this, this.constructor);
  }

  toJSON() {
    return {
      error: {
        code: this.code,
        message: this.message,
        ...(this.details && { details: this.details }),
      },
    };
  }
}

/**
 * Common error factory functions
 */
export const Errors = {
  badRequest: (message: string, details?: Record<string, unknown>) =>
    new AppError('BAD_REQUEST', message, 400, details),

  unauthorized: (message = 'Authentication required') =>
    new AppError('UNAUTHORIZED', message, 401),

  forbidden: (message = 'Insufficient permissions') =>
    new AppError('FORBIDDEN', message, 403),

  notFound: (resource: string, id?: string) =>
    new AppError(
      'NOT_FOUND',
      id ? `${resource} with id '${id}' not found` : `${resource} not found`,
      404
    ),

  conflict: (message: string) =>
    new AppError('CONFLICT', message, 409),

  rateLimited: (retryAfter: number) =>
    new AppError('RATE_LIMITED', `Too many requests. Retry after ${retryAfter} seconds.`, 429, {
      retryAfter,
    }),

  internal: (message = 'An unexpected error occurred') =>
    new AppError('INTERNAL_ERROR', message, 500),

  serviceUnavailable: (service: string) =>
    new AppError('SERVICE_UNAVAILABLE', `${service} is currently unavailable`, 503),

  validation: (errors: ValidationErrorItem[]) =>
    new AppError('VALIDATION_ERROR', 'Request validation failed', 400, {
      validationErrors: errors,
    }),
};

interface ValidationErrorItem {
  field: string;
  message: string;
  code?: string;
}

/**
 * Format Zod validation errors
 */
function formatZodError(error: ZodError): ValidationErrorItem[] {
  return error.errors.map((e) => ({
    field: e.path.join('.'),
    message: e.message,
    code: e.code,
  }));
}

/**
 * Global error handler for Fastify
 */
export function errorHandler(
  error: FastifyError | AppError | ZodError | Error,
  request: FastifyRequest,
  reply: FastifyReply
): void {
  const requestId = request.id;

  // Handle Zod validation errors
  if (error instanceof ZodError) {
    const validationErrors = formatZodError(error);
    logger.warn({ requestId, validationErrors }, 'Validation error');

    reply.status(400).send({
      error: {
        code: 'VALIDATION_ERROR',
        message: 'Request validation failed',
        validationErrors,
        requestId,
      },
    });
    return;
  }

  // Handle application errors
  if (error instanceof AppError) {
    const logLevel = error.statusCode >= 500 ? 'error' : 'warn';
    logger[logLevel](
      { requestId, code: error.code, statusCode: error.statusCode },
      error.message
    );

    reply.status(error.statusCode).send({
      error: {
        code: error.code,
        message: error.message,
        ...(error.details && { details: error.details }),
        requestId,
      },
    });
    return;
  }

  // Handle Fastify errors (validation, rate limit, etc.)
  if ('statusCode' in error && typeof error.statusCode === 'number') {
    const statusCode = error.statusCode;
    const code = error.code || 'FASTIFY_ERROR';

    if (statusCode >= 500) {
      logger.error({ requestId, err: error }, 'Server error');
    } else {
      logger.warn({ requestId, code, statusCode }, error.message);
    }

    reply.status(statusCode).send({
      error: {
        code,
        message: error.message,
        requestId,
      },
    });
    return;
  }

  // Handle unknown errors
  logger.error({ requestId, err: error }, 'Unhandled error');

  reply.status(500).send({
    error: {
      code: 'INTERNAL_ERROR',
      message: process.env.NODE_ENV === 'production'
        ? 'An unexpected error occurred'
        : error.message,
      requestId,
    },
  });
}
