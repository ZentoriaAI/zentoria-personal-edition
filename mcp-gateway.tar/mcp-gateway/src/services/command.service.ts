/**
 * Command Service
 *
 * Handles AI command processing via the AI Orchestrator (405)
 */

import { nanoid } from 'nanoid';
import { z } from 'zod';
import type { ContainerCradle } from '../container.js';
import { Errors } from '../middleware/error-handler.js';

// Validation schemas
export const CommandRequestSchema = z.object({
  command: z.string().min(1).max(32000),
  sessionId: z.string().regex(/^sess_[a-zA-Z0-9]+$/).optional(),
  context: z.object({
    files: z.array(z.string()).max(10).optional(),
    previousMessages: z.number().min(0).max(50).default(10).optional(),
    systemPrompt: z.string().max(4000).optional(),
    variables: z.record(z.string()).optional(),
  }).optional(),
  options: z.object({
    model: z.enum(['claude-3-5-sonnet', 'claude-3-opus', 'gpt-4-turbo', 'gpt-4o']).default('claude-3-5-sonnet'),
    maxTokens: z.number().min(1).max(16384).default(4096).optional(),
    temperature: z.number().min(0).max(2).default(0.7).optional(),
    stream: z.boolean().default(false).optional(),
    async: z.boolean().default(false).optional(),
  }).optional(),
});

export type CommandRequest = z.infer<typeof CommandRequestSchema>;

export interface CommandResponse {
  id: string;
  content: string;
  model: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  sessionId?: string;
  finishReason: 'stop' | 'max_tokens' | 'error';
  metadata?: Record<string, unknown>;
}

export interface AsyncCommandResponse {
  id: string;
  status: 'queued' | 'processing';
  estimatedCompletionMs?: number;
  pollingUrl: string;
  websocketUrl: string;
}

export class CommandService {
  private readonly aiOrchestratorClient: ContainerCradle['aiOrchestratorClient'];
  private readonly circuitBreaker: ContainerCradle['circuitBreaker'];
  private readonly redis: ContainerCradle['redis'];
  private readonly fileRepository: ContainerCradle['fileRepository'];
  private readonly auditRepository: ContainerCradle['auditRepository'];
  private readonly logger: ContainerCradle['logger'];

  constructor({
    aiOrchestratorClient,
    circuitBreaker,
    redis,
    fileRepository,
    auditRepository,
    logger,
  }: ContainerCradle) {
    this.aiOrchestratorClient = aiOrchestratorClient;
    this.circuitBreaker = circuitBreaker;
    this.redis = redis;
    this.fileRepository = fileRepository;
    this.auditRepository = auditRepository;
    this.logger = logger;
  }

  /**
   * Process a command synchronously
   */
  async processCommand(
    userId: string,
    request: CommandRequest
  ): Promise<CommandResponse> {
    const commandId = `cmd_${nanoid(16)}`;

    this.logger.info({ commandId, userId }, 'Processing command');

    // Validate and fetch file contexts if provided
    let fileContexts: string[] = [];
    if (request.context?.files?.length) {
      fileContexts = await this.fetchFileContexts(userId, request.context.files);
    }

    // Build the payload for AI Orchestrator
    const payload = {
      id: commandId,
      userId,
      command: request.command,
      sessionId: request.sessionId,
      fileContexts,
      systemPrompt: request.context?.systemPrompt,
      variables: request.context?.variables,
      previousMessages: request.context?.previousMessages ?? 10,
      model: request.options?.model ?? 'claude-3-5-sonnet',
      maxTokens: request.options?.maxTokens ?? 4096,
      temperature: request.options?.temperature ?? 0.7,
    };

    try {
      // Execute with circuit breaker protection
      const result = await this.circuitBreaker.execute(
        'ai-orchestrator',
        () => this.aiOrchestratorClient.processCommand(payload),
        { timeout: 120000 } // 2 minutes for AI processing
      );

      // Log audit
      await this.auditRepository.log({
        action: 'command_processed',
        userId,
        metadata: {
          commandId,
          model: payload.model,
          promptTokens: result.usage.promptTokens,
          completionTokens: result.usage.completionTokens,
        },
      });

      return {
        id: commandId,
        content: result.content,
        model: result.model,
        usage: result.usage,
        sessionId: request.sessionId,
        finishReason: result.finishReason,
        metadata: result.metadata,
      };
    } catch (err) {
      this.logger.error({ err, commandId }, 'Command processing failed');

      // Check if circuit is open
      const state = this.circuitBreaker.getState('ai-orchestrator');
      if (state === 'open') {
        throw Errors.serviceUnavailable('AI Orchestrator');
      }

      throw err;
    }
  }

  /**
   * Queue a command for async processing
   */
  async queueCommand(
    userId: string,
    request: CommandRequest
  ): Promise<AsyncCommandResponse> {
    const commandId = `cmd_${nanoid(16)}`;

    this.logger.info({ commandId, userId }, 'Queueing command for async processing');

    // Store command in Redis for processing
    const commandData = {
      id: commandId,
      userId,
      request,
      status: 'queued',
      createdAt: new Date().toISOString(),
    };

    await this.redis.setex(
      `command:${commandId}`,
      3600, // 1 hour TTL
      JSON.stringify(commandData)
    );

    // Publish to queue for worker processing
    await this.redis.lpush('command:queue', commandId);

    // Log audit
    await this.auditRepository.log({
      action: 'command_queued',
      userId,
      metadata: { commandId },
    });

    const baseUrl = process.env.BASE_URL || 'http://localhost:4000';

    return {
      id: commandId,
      status: 'queued',
      estimatedCompletionMs: 30000,
      pollingUrl: `${baseUrl}/api/v1/mcp/command/${commandId}`,
      websocketUrl: `${baseUrl.replace('http', 'ws')}/ws/command/${commandId}`,
    };
  }

  /**
   * Get status of an async command
   */
  async getCommandStatus(commandId: string): Promise<{
    status: 'queued' | 'processing' | 'completed' | 'failed';
    result?: CommandResponse;
    error?: string;
  }> {
    const data = await this.redis.get(`command:${commandId}`);
    if (!data) {
      throw Errors.notFound('Command', commandId);
    }

    const command = JSON.parse(data);
    return {
      status: command.status,
      result: command.result,
      error: command.error,
    };
  }

  /**
   * Fetch file contents for context injection
   */
  private async fetchFileContexts(
    userId: string,
    fileIds: string[]
  ): Promise<string[]> {
    const contexts: string[] = [];

    for (const fileId of fileIds) {
      const file = await this.fileRepository.findById(fileId);

      if (!file) {
        this.logger.warn({ fileId }, 'File not found for context');
        continue;
      }

      if (file.userId !== userId) {
        this.logger.warn({ fileId, userId }, 'File access denied');
        continue;
      }

      // Only include text-based files
      if (!file.mimeType.startsWith('text/') && file.mimeType !== 'application/json') {
        this.logger.info({ fileId, mimeType: file.mimeType }, 'Skipping non-text file');
        continue;
      }

      // Fetch file content (simplified - in production, stream from MinIO)
      const content = await this.fileRepository.getContent(fileId);
      if (content) {
        contexts.push(`--- File: ${file.filename} ---\n${content}\n--- End File ---`);
      }
    }

    return contexts;
  }
}
