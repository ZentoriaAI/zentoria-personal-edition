/**
 * File Service
 *
 * Handles file upload, storage, and retrieval via MinIO
 */

import { nanoid } from 'nanoid';
import { Readable } from 'stream';
import { createHash } from 'crypto';
import { z } from 'zod';
import type { Client as MinioClient } from 'minio';
import type { ContainerCradle } from '../container.js';
import { Errors } from '../middleware/error-handler.js';
import { MinioKeys, getPresignedGetUrl } from '../infrastructure/minio.js';

// Validation schemas
export const FileUploadMetadataSchema = z.object({
  purpose: z.enum(['ai-input', 'attachment', 'backup']).default('ai-input'),
  metadata: z.record(z.string()).optional(),
});

export const FileListQuerySchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
  purpose: z.enum(['ai-input', 'attachment', 'backup']).optional(),
  createdAfter: z.string().datetime().optional(),
  createdBefore: z.string().datetime().optional(),
});

export interface FileUploadResult {
  id: string;
  filename: string;
  size: number;
  mimeType: string;
  purpose: string;
  checksum: string;
  createdAt: string;
  expiresAt?: string;
}

export interface FileMetadata {
  id: string;
  filename: string;
  size: number;
  mimeType: string;
  purpose: string;
  checksum: string;
  metadata?: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export interface FileListResult {
  files: FileMetadata[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

const ALLOWED_MIME_TYPES = (process.env.ALLOWED_MIME_TYPES || 'application/pdf,image/*,text/*,application/json')
  .split(',')
  .map(t => t.trim());

const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE_MB || '100', 10) * 1024 * 1024;

export class FileService {
  private readonly minio: MinioClient;
  private readonly fileRepository: ContainerCradle['fileRepository'];
  private readonly auditRepository: ContainerCradle['auditRepository'];
  private readonly logger: ContainerCradle['logger'];
  private readonly bucket: string;

  constructor({
    minio,
    fileRepository,
    auditRepository,
    logger,
  }: ContainerCradle) {
    this.minio = minio;
    this.fileRepository = fileRepository;
    this.auditRepository = auditRepository;
    this.logger = logger;
    this.bucket = process.env.MINIO_BUCKET || 'zentoria-files';
  }

  /**
   * Upload a file
   */
  async uploadFile(
    userId: string,
    filename: string,
    mimeType: string,
    stream: Readable,
    size: number,
    options: z.infer<typeof FileUploadMetadataSchema>
  ): Promise<FileUploadResult> {
    // Validate mime type
    if (!this.isAllowedMimeType(mimeType)) {
      throw Errors.badRequest(`File type '${mimeType}' is not allowed`);
    }

    // Validate size
    if (size > MAX_FILE_SIZE) {
      throw Errors.badRequest(`File size exceeds maximum of ${MAX_FILE_SIZE / 1024 / 1024}MB`);
    }

    const fileId = `file_${nanoid(16)}`;
    const objectName = MinioKeys.userFile(userId, fileId, filename);

    this.logger.info({ fileId, filename, size, mimeType }, 'Starting file upload');

    // Calculate checksum while uploading
    const hash = createHash('sha256');
    const checksumStream = new Readable({
      read() {},
    });

    let uploadedSize = 0;

    stream.on('data', (chunk: Buffer) => {
      hash.update(chunk);
      uploadedSize += chunk.length;
      checksumStream.push(chunk);
    });

    stream.on('end', () => {
      checksumStream.push(null);
    });

    stream.on('error', (err) => {
      checksumStream.destroy(err);
    });

    try {
      // Upload to MinIO
      await this.minio.putObject(
        this.bucket,
        objectName,
        checksumStream,
        size,
        {
          'Content-Type': mimeType,
          'x-amz-meta-user-id': userId,
          'x-amz-meta-file-id': fileId,
          'x-amz-meta-purpose': options.purpose,
        }
      );

      const checksum = hash.digest('hex');

      // Store metadata in database
      const fileRecord = await this.fileRepository.create({
        id: fileId,
        userId,
        filename,
        mimeType,
        size: uploadedSize,
        purpose: options.purpose,
        checksum,
        objectName,
        metadata: options.metadata,
      });

      // Log audit
      await this.auditRepository.log({
        action: 'file_uploaded',
        userId,
        metadata: {
          fileId,
          filename,
          size: uploadedSize,
          mimeType,
        },
      });

      this.logger.info({ fileId, checksum }, 'File upload completed');

      return {
        id: fileId,
        filename,
        size: uploadedSize,
        mimeType,
        purpose: options.purpose,
        checksum,
        createdAt: fileRecord.createdAt.toISOString(),
      };
    } catch (err) {
      this.logger.error({ err, fileId }, 'File upload failed');

      // Cleanup on failure
      try {
        await this.minio.removeObject(this.bucket, objectName);
      } catch {
        // Ignore cleanup errors
      }

      throw err;
    }
  }

  /**
   * List files for a user
   */
  async listFiles(
    userId: string,
    query: z.infer<typeof FileListQuerySchema>
  ): Promise<FileListResult> {
    const { page, limit, purpose, createdAfter, createdBefore } = query;
    const offset = (page - 1) * limit;

    const { files, total } = await this.fileRepository.findByUser(userId, {
      limit,
      offset,
      purpose,
      createdAfter: createdAfter ? new Date(createdAfter) : undefined,
      createdBefore: createdBefore ? new Date(createdBefore) : undefined,
    });

    const totalPages = Math.ceil(total / limit);

    return {
      files: files.map(this.mapToMetadata),
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
    };
  }

  /**
   * Get file metadata
   */
  async getFile(userId: string, fileId: string): Promise<FileMetadata> {
    const file = await this.fileRepository.findById(fileId);

    if (!file) {
      throw Errors.notFound('File', fileId);
    }

    if (file.userId !== userId) {
      throw Errors.forbidden('You do not have access to this file');
    }

    return this.mapToMetadata(file);
  }

  /**
   * Delete a file
   */
  async deleteFile(userId: string, fileId: string): Promise<void> {
    const file = await this.fileRepository.findById(fileId);

    if (!file) {
      throw Errors.notFound('File', fileId);
    }

    if (file.userId !== userId) {
      throw Errors.forbidden('You do not have access to this file');
    }

    this.logger.info({ fileId }, 'Deleting file');

    // Delete from MinIO
    await this.minio.removeObject(this.bucket, file.objectName);

    // Delete from database
    await this.fileRepository.delete(fileId);

    // Log audit
    await this.auditRepository.log({
      action: 'file_deleted',
      userId,
      metadata: {
        fileId,
        filename: file.filename,
      },
    });
  }

  /**
   * Get a presigned download URL
   */
  async getDownloadUrl(userId: string, fileId: string): Promise<string> {
    const file = await this.fileRepository.findById(fileId);

    if (!file) {
      throw Errors.notFound('File', fileId);
    }

    if (file.userId !== userId) {
      throw Errors.forbidden('You do not have access to this file');
    }

    return getPresignedGetUrl(this.minio, this.bucket, file.objectName, 3600);
  }

  /**
   * Stream file content
   */
  async getFileStream(userId: string, fileId: string): Promise<{
    stream: Readable;
    metadata: FileMetadata;
  }> {
    const file = await this.fileRepository.findById(fileId);

    if (!file) {
      throw Errors.notFound('File', fileId);
    }

    if (file.userId !== userId) {
      throw Errors.forbidden('You do not have access to this file');
    }

    const stream = await this.minio.getObject(this.bucket, file.objectName);

    return {
      stream,
      metadata: this.mapToMetadata(file),
    };
  }

  /**
   * Check if mime type is allowed
   */
  private isAllowedMimeType(mimeType: string): boolean {
    return ALLOWED_MIME_TYPES.some(pattern => {
      if (pattern.endsWith('/*')) {
        return mimeType.startsWith(pattern.slice(0, -1));
      }
      return pattern === mimeType;
    });
  }

  /**
   * Map database record to API response
   */
  private mapToMetadata(file: {
    id: string;
    filename: string;
    size: number;
    mimeType: string;
    purpose: string;
    checksum: string;
    metadata?: Record<string, string> | null;
    createdAt: Date;
    updatedAt: Date;
  }): FileMetadata {
    return {
      id: file.id,
      filename: file.filename,
      size: file.size,
      mimeType: file.mimeType,
      purpose: file.purpose,
      checksum: file.checksum,
      metadata: file.metadata || undefined,
      createdAt: file.createdAt.toISOString(),
      updatedAt: file.updatedAt.toISOString(),
    };
  }
}
