/**
 * Redis Client Configuration
 */

import Redis from 'ioredis';
import { logger } from './logger.js';

export async function createRedisClient(): Promise<Redis> {
  const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
  const redisPassword = process.env.REDIS_PASSWORD;

  const client = new Redis(redisUrl, {
    password: redisPassword || undefined,
    maxRetriesPerRequest: 3,
    retryStrategy: (times) => {
      if (times > 10) {
        logger.error('Redis connection failed after 10 retries');
        return null; // Stop retrying
      }
      const delay = Math.min(times * 100, 3000);
      logger.warn({ times, delay }, 'Retrying Redis connection');
      return delay;
    },
    lazyConnect: true,
  });

  client.on('connect', () => {
    logger.info('Redis connected');
  });

  client.on('error', (err) => {
    logger.error({ err }, 'Redis error');
  });

  client.on('close', () => {
    logger.warn('Redis connection closed');
  });

  // Connect
  try {
    await client.connect();
  } catch (err) {
    logger.error({ err }, 'Failed to connect to Redis');
    throw err;
  }

  return client;
}

/**
 * Redis key prefixes for different data types
 */
export const RedisKeys = {
  session: (id: string) => `session:${id}`,
  apiKey: (key: string) => `apikey:${key}`,
  rateLimit: (key: string) => `ratelimit:${key}`,
  cache: (key: string) => `cache:${key}`,
  lock: (key: string) => `lock:${key}`,
  pubsub: {
    commandResult: 'pubsub:command:result',
    fileUpload: 'pubsub:file:upload',
    workflow: 'pubsub:workflow',
  },
} as const;
