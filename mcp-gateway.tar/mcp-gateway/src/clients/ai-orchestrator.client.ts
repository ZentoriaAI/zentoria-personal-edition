/**
 * AI Orchestrator HTTP Client
 *
 * Communicates with AI Orchestrator Service (Container 405)
 */

import type { ContainerCradle } from '../container.js';

export interface ProcessCommandPayload {
  id: string;
  userId: string;
  command: string;
  sessionId?: string;
  fileContexts?: string[];
  systemPrompt?: string;
  variables?: Record<string, string>;
  previousMessages?: number;
  model: string;
  maxTokens: number;
  temperature: number;
}

export interface CommandResult {
  content: string;
  model: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  finishReason: 'stop' | 'max_tokens' | 'error';
  metadata?: Record<string, unknown>;
}

export class AiOrchestratorClient {
  private readonly baseUrl: string;
  private readonly logger: ContainerCradle['logger'];

  constructor({ logger }: ContainerCradle) {
    this.baseUrl = process.env.AI_ORCHESTRATOR_URL || 'http://ai-orchestrator:4005';
    this.logger = logger;
  }

  /**
   * Process an AI command
   */
  async processCommand(payload: ProcessCommandPayload): Promise<CommandResult> {
    this.logger.debug({ commandId: payload.id }, 'Sending command to AI Orchestrator');

    const response = await fetch(`${this.baseUrl}/api/v1/process`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Service-Auth': process.env.SERVICE_AUTH_TOKEN || '',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.text();
      this.logger.error(
        { status: response.status, error },
        'AI Orchestrator request failed'
      );
      throw new Error(`AI Orchestrator error: ${response.status} - ${error}`);
    }

    return response.json() as Promise<CommandResult>;
  }

  /**
   * Process command with streaming
   */
  async *processCommandStream(
    payload: ProcessCommandPayload
  ): AsyncGenerator<{ type: 'chunk' | 'done' | 'error'; content?: string; usage?: CommandResult['usage'] }> {
    const response = await fetch(`${this.baseUrl}/api/v1/process/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Service-Auth': process.env.SERVICE_AUTH_TOKEN || '',
        'Accept': 'text/event-stream',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.text();
      yield { type: 'error', content: error };
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) {
      yield { type: 'error', content: 'No response body' };
      return;
    }

    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        // Parse SSE format
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              yield { type: 'done' };
              return;
            }

            try {
              const parsed = JSON.parse(data);
              yield { type: 'chunk', content: parsed.content, usage: parsed.usage };
            } catch {
              // Skip invalid JSON
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }

  /**
   * Get available models
   */
  async getModels(): Promise<string[]> {
    const response = await fetch(`${this.baseUrl}/api/v1/models`, {
      method: 'GET',
      headers: {
        'X-Service-Auth': process.env.SERVICE_AUTH_TOKEN || '',
      },
    });

    if (!response.ok) {
      return ['claude-3-5-sonnet']; // Default fallback
    }

    const data = await response.json() as { models: string[] };
    return data.models;
  }

  /**
   * Check service health
   */
  async health(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}
