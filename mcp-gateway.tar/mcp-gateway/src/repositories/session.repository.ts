/**
 * Session Repository
 *
 * Manages conversation sessions for context continuity
 */

import { nanoid } from 'nanoid';
import type { ContainerCradle } from '../container.js';

export interface SessionData {
  id: string;
  userId: string;
  messages: SessionMessage[];
  context?: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
  expiresAt: Date;
}

export interface SessionMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

const SESSION_TTL_SECONDS = 3600 * 24; // 24 hours

export class SessionRepository {
  private readonly redis: ContainerCradle['redis'];
  private readonly logger: ContainerCradle['logger'];

  constructor({ redis, logger }: ContainerCradle) {
    this.redis = redis;
    this.logger = logger;
  }

  /**
   * Create a new session
   */
  async create(userId: string, context?: Record<string, unknown>): Promise<SessionData> {
    const id = `sess_${nanoid(16)}`;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + SESSION_TTL_SECONDS * 1000);

    const session: SessionData = {
      id,
      userId,
      messages: [],
      context,
      createdAt: now,
      updatedAt: now,
      expiresAt,
    };

    await this.redis.setex(
      `session:${id}`,
      SESSION_TTL_SECONDS,
      JSON.stringify(session)
    );

    return session;
  }

  /**
   * Get a session by ID
   */
  async get(id: string): Promise<SessionData | null> {
    const data = await this.redis.get(`session:${id}`);
    if (!data) {
      return null;
    }

    return JSON.parse(data) as SessionData;
  }

  /**
   * Add a message to a session
   */
  async addMessage(
    sessionId: string,
    message: Omit<SessionMessage, 'timestamp'>
  ): Promise<SessionData | null> {
    const session = await this.get(sessionId);
    if (!session) {
      return null;
    }

    const newMessage: SessionMessage = {
      ...message,
      timestamp: new Date().toISOString(),
    };

    session.messages.push(newMessage);
    session.updatedAt = new Date();

    // Refresh TTL
    await this.redis.setex(
      `session:${sessionId}`,
      SESSION_TTL_SECONDS,
      JSON.stringify(session)
    );

    return session;
  }

  /**
   * Get recent messages from a session
   */
  async getRecentMessages(
    sessionId: string,
    count: number
  ): Promise<SessionMessage[]> {
    const session = await this.get(sessionId);
    if (!session) {
      return [];
    }

    return session.messages.slice(-count);
  }

  /**
   * Update session context
   */
  async updateContext(
    sessionId: string,
    context: Record<string, unknown>
  ): Promise<SessionData | null> {
    const session = await this.get(sessionId);
    if (!session) {
      return null;
    }

    session.context = { ...session.context, ...context };
    session.updatedAt = new Date();

    await this.redis.setex(
      `session:${sessionId}`,
      SESSION_TTL_SECONDS,
      JSON.stringify(session)
    );

    return session;
  }

  /**
   * Delete a session
   */
  async delete(sessionId: string): Promise<void> {
    await this.redis.del(`session:${sessionId}`);
  }

  /**
   * List user's active sessions
   */
  async listByUser(userId: string): Promise<SessionData[]> {
    // Note: In production, consider indexing sessions by user
    // This implementation scans all session keys
    const sessions: SessionData[] = [];
    let cursor = '0';

    do {
      const [newCursor, keys] = await this.redis.scan(
        cursor,
        'MATCH',
        'session:sess_*',
        'COUNT',
        100
      );
      cursor = newCursor;

      for (const key of keys) {
        const data = await this.redis.get(key);
        if (data) {
          const session = JSON.parse(data) as SessionData;
          if (session.userId === userId) {
            sessions.push(session);
          }
        }
      }
    } while (cursor !== '0');

    return sessions.sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }
}
