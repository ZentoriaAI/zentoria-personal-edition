/**
 * Audit Repository
 *
 * Logs all operations for compliance and debugging
 */

import type { ContainerCradle } from '../container.js';

export interface AuditLogEntry {
  id: string;
  action: string;
  userId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export interface LogAuditData {
  action: string;
  userId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
}

export class AuditRepository {
  private readonly prisma: ContainerCradle['prisma'];
  private readonly logger: ContainerCradle['logger'];

  constructor({ prisma, logger }: ContainerCradle) {
    this.prisma = prisma;
    this.logger = logger;
  }

  /**
   * Log an audit entry
   */
  async log(data: LogAuditData): Promise<void> {
    try {
      await this.prisma.auditLog.create({
        data: {
          action: data.action,
          userId: data.userId,
          metadata: data.metadata || {},
          ipAddress: data.ipAddress,
          userAgent: data.userAgent,
        },
      });
    } catch (err) {
      // Don't fail operations due to audit logging errors
      this.logger.error({ err, action: data.action }, 'Failed to write audit log');
    }
  }

  /**
   * Query audit logs
   */
  async query(options: {
    userId?: string;
    action?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{ entries: AuditLogEntry[]; total: number }> {
    const where = {
      ...(options.userId && { userId: options.userId }),
      ...(options.action && { action: options.action }),
      ...(options.startDate || options.endDate
        ? {
            createdAt: {
              ...(options.startDate && { gte: options.startDate }),
              ...(options.endDate && { lte: options.endDate }),
            },
          }
        : {}),
    };

    const [results, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        where,
        take: options.limit || 100,
        skip: options.offset || 0,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.auditLog.count({ where }),
    ]);

    return {
      entries: results.map((r) => ({
        id: r.id,
        action: r.action,
        userId: r.userId || undefined,
        metadata: r.metadata as Record<string, unknown> | undefined,
        ipAddress: r.ipAddress || undefined,
        userAgent: r.userAgent || undefined,
        createdAt: r.createdAt,
      })),
      total,
    };
  }
}
