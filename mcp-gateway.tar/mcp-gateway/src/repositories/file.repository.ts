/**
 * File Repository
 */

import type { ContainerCradle } from '../container.js';

export interface FileRecord {
  id: string;
  userId: string;
  filename: string;
  mimeType: string;
  size: number;
  purpose: string;
  checksum: string;
  objectName: string;
  metadata?: Record<string, string> | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateFileData {
  id: string;
  userId: string;
  filename: string;
  mimeType: string;
  size: number;
  purpose: string;
  checksum: string;
  objectName: string;
  metadata?: Record<string, string>;
}

export interface FindFilesOptions {
  limit: number;
  offset: number;
  purpose?: string;
  createdAfter?: Date;
  createdBefore?: Date;
}

export class FileRepository {
  private readonly prisma: ContainerCradle['prisma'];
  private readonly minio: ContainerCradle['minio'];
  private readonly logger: ContainerCradle['logger'];

  constructor({ prisma, minio, logger }: ContainerCradle) {
    this.prisma = prisma;
    this.minio = minio;
    this.logger = logger;
  }

  async create(data: CreateFileData): Promise<FileRecord> {
    const result = await this.prisma.file.create({
      data: {
        id: data.id,
        userId: data.userId,
        filename: data.filename,
        mimeType: data.mimeType,
        size: data.size,
        purpose: data.purpose,
        checksum: data.checksum,
        objectName: data.objectName,
        metadata: data.metadata || {},
      },
    });

    return this.mapToRecord(result);
  }

  async findById(id: string): Promise<FileRecord | null> {
    const result = await this.prisma.file.findUnique({
      where: { id },
    });

    return result ? this.mapToRecord(result) : null;
  }

  async findByUser(
    userId: string,
    options: FindFilesOptions
  ): Promise<{ files: FileRecord[]; total: number }> {
    const where = {
      userId,
      ...(options.purpose && { purpose: options.purpose }),
      ...(options.createdAfter && { createdAt: { gte: options.createdAfter } }),
      ...(options.createdBefore && { createdAt: { lte: options.createdBefore } }),
    };

    const [results, total] = await Promise.all([
      this.prisma.file.findMany({
        where,
        take: options.limit,
        skip: options.offset,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.file.count({ where }),
    ]);

    return {
      files: results.map(this.mapToRecord),
      total,
    };
  }

  async delete(id: string): Promise<void> {
    await this.prisma.file.delete({
      where: { id },
    });
  }

  async getContent(id: string): Promise<string | null> {
    const file = await this.findById(id);
    if (!file) {
      return null;
    }

    try {
      const bucket = process.env.MINIO_BUCKET || 'zentoria-files';
      const stream = await this.minio.getObject(bucket, file.objectName);

      const chunks: Buffer[] = [];
      for await (const chunk of stream) {
        chunks.push(Buffer.from(chunk));
      }

      return Buffer.concat(chunks).toString('utf-8');
    } catch (err) {
      this.logger.error({ err, fileId: id }, 'Failed to get file content');
      return null;
    }
  }

  private mapToRecord(data: {
    id: string;
    userId: string;
    filename: string;
    mimeType: string;
    size: number;
    purpose: string;
    checksum: string;
    objectName: string;
    metadata: unknown;
    createdAt: Date;
    updatedAt: Date;
  }): FileRecord {
    return {
      id: data.id,
      userId: data.userId,
      filename: data.filename,
      mimeType: data.mimeType,
      size: data.size,
      purpose: data.purpose,
      checksum: data.checksum,
      objectName: data.objectName,
      metadata: data.metadata as Record<string, string> | null,
      createdAt: data.createdAt,
      updatedAt: data.updatedAt,
    };
  }
}
